package dev.coppergear.client;

import dev.coppergear.CopperGolem;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public class CopperGolemRenderer extends MobRenderer<CopperGolem, CopperGolemModel> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[4];
    static {
        for (int i = 0; i < 4; i++) TEXTURES[i] = new ResourceLocation("coppergear", "textures/entity/copper_golem_" + i + ".png");
    }

    public CopperGolemRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new CopperGolemModel(ctx.bakeLayer(CopperGolemModel.LAYER)), 0.35F);
        addLayer(new ItemInHandLayer<>(this, ctx.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(CopperGolem golem) {
        return TEXTURES[Math.max(0, Math.min(3, golem.getStage()))];
    }
}
