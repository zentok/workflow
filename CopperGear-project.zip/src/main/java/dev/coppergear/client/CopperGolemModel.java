package dev.coppergear.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.coppergear.CopperGolem;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/** Small copper golem with a lightning-rod antenna. */
public class CopperGolemModel extends EntityModel<CopperGolem> implements ArmedModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation("coppergear", "copper_golem"), "main");

    private final ModelPart head, body, rightArm, leftArm, rightLeg, leftLeg;

    public CopperGolemModel(ModelPart root) {
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();
        PartDefinition headPart = p.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offset(0.0F, 15.0F, 0.0F));
        headPart.addOrReplaceChild("rod", CubeListBuilder.create().texOffs(40, 32).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offset(0.0F, -8.0F, 0.0F));
        p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-4.0F, -6.0F, -3.0F, 8.0F, 6.0F, 6.0F), PartPose.offset(0.0F, 21.0F, 0.0F));
        p.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(32, 16).addBox(-2.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offset(-4.0F, 16.0F, 0.0F));
        p.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(32, 16).mirror().addBox(0.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offset(4.0F, 16.0F, 0.0F));
        p.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 32).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.offset(-2.0F, 21.0F, 0.0F));
        p.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 32).mirror().addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.offset(2.0F, 21.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(CopperGolem golem, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        boolean statue = golem.getStage() >= 3;
        if (statue) { limbSwing = 0.0F; limbSwingAmount = 0.0F; }
        head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        head.xRot = headPitch * ((float) Math.PI / 180F);
        rightLeg.xRot = Mth.cos(limbSwing * 0.8F) * 1.2F * limbSwingAmount;
        leftLeg.xRot = -Mth.cos(limbSwing * 0.8F) * 1.2F * limbSwingAmount;
        if (!golem.getMainHandItem().isEmpty()) {          // carrying: both arms forward
            rightArm.xRot = -1.3F;
            leftArm.xRot = -1.3F;
        } else {
            rightArm.xRot = -Mth.cos(limbSwing * 0.8F) * 0.8F * limbSwingAmount;
            leftArm.xRot = Mth.cos(limbSwing * 0.8F) * 0.8F * limbSwingAmount;
        }
        float swing = golem.attackAnim;
        if (swing > 0.0F) {
            rightArm.xRot = -Mth.sin(swing * (float) Math.PI) * 2.2F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        head.render(pose, vc, light, overlay, r, g, b, a);
        body.render(pose, vc, light, overlay, r, g, b, a);
        rightArm.render(pose, vc, light, overlay, r, g, b, a);
        leftArm.render(pose, vc, light, overlay, r, g, b, a);
        rightLeg.render(pose, vc, light, overlay, r, g, b, a);
        leftLeg.render(pose, vc, light, overlay, r, g, b, a);
    }

    @Override
    public void translateToHand(HumanoidArm arm, PoseStack pose) {
        (arm == HumanoidArm.LEFT ? leftArm : rightArm).translateAndRotate(pose);
        pose.translate(0.0F, 0.25F, -0.1F);
    }
}
