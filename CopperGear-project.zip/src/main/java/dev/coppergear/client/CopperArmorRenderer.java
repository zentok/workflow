package dev.coppergear.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.coppergear.Weathering;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/** Draws the worn armor with the texture of its current oxidation stage. */
public class CopperArmorRenderer implements ArmorRenderer {
    private HumanoidModel<LivingEntity> inner, outer;

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, ItemStack stack, LivingEntity entity,
                       EquipmentSlot slot, int light, HumanoidModel<LivingEntity> context) {
        if (inner == null) {
            EntityModelSet set = Minecraft.getInstance().getEntityModels();
            inner = new HumanoidModel<>(set.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR));
            outer = new HumanoidModel<>(set.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR));
        }
        HumanoidModel<LivingEntity> model = slot == EquipmentSlot.LEGS ? inner : outer;
        context.copyPropertiesTo(model);
        model.setAllVisible(false);
        switch (slot) {
            case HEAD -> { model.head.visible = true; model.hat.visible = true; }
            case CHEST -> { model.body.visible = true; model.rightArm.visible = true; model.leftArm.visible = true; }
            case LEGS -> { model.body.visible = true; model.rightLeg.visible = true; model.leftLeg.visible = true; }
            case FEET -> { model.rightLeg.visible = true; model.leftLeg.visible = true; }
            default -> { }
        }
        int layer = slot == EquipmentSlot.LEGS ? 2 : 1;
        ResourceLocation tex = new ResourceLocation("coppergear",
                "textures/models/armor/copper_layer_" + layer + "_" + Weathering.stage(stack) + ".png");
        VertexConsumer vc = ItemRenderer.getArmorFoilBuffer(buffers, RenderType.armorCutoutNoCull(tex), false, stack.hasFoil());
        model.renderToBuffer(pose, vc, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }
}
