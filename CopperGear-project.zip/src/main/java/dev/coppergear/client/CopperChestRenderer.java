package dev.coppergear.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.coppergear.CopperChestBlockEntity;
import dev.coppergear.CopperGearMod;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.resources.model.Material;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Vanilla chest model, but with one of four oxidation textures. */
public class CopperChestRenderer implements BlockEntityRenderer<CopperChestBlockEntity> {
    private static final Material[] MATERIALS = new Material[4];
    static {
        for (int i = 0; i < 4; i++) {
            MATERIALS[i] = new Material(Sheets.CHEST_SHEET, new ResourceLocation(CopperGearMod.ID, "entity/chest/copper_" + i));
        }
    }

    private final ModelPart lid, bottom, lock;

    public CopperChestRenderer(BlockEntityRendererProvider.Context ctx) {
        ModelPart root = ctx.bakeLayer(ModelLayers.CHEST);
        this.bottom = root.getChild("bottom");
        this.lid = root.getChild("lid");
        this.lock = root.getChild("lock");
    }

    @Override
    public void render(CopperChestBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        boolean inWorld = be.getLevel() != null;
        BlockState state = inWorld ? be.getBlockState()
                : CopperGearMod.COPPER_CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.SOUTH);
        float angle = state.getValue(ChestBlock.FACING).toYRot();
        int stage = inWorld ? be.getStage() : 0;

        pose.pushPose();
        pose.translate(0.5F, 0.5F, 0.5F);
        pose.mulPose(Axis.YP.rotationDegrees(-angle));
        pose.translate(-0.5F, -0.5F, -0.5F);

        float open = inWorld ? be.getOpenNess(partialTick) : 0.0F;
        open = 1.0F - open;
        open = 1.0F - open * open * open;

        VertexConsumer vc = MATERIALS[stage].buffer(buffers, RenderType::entityCutout);
        lid.xRot = -(open * ((float) Math.PI / 2F));
        lock.xRot = lid.xRot;
        lid.render(pose, vc, light, overlay);
        lock.render(pose, vc, light, overlay);
        bottom.render(pose, vc, light, overlay);
        pose.popPose();
    }
}
