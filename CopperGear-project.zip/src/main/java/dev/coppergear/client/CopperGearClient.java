package dev.coppergear.client;

import dev.coppergear.CopperChestBlockEntity;
import dev.coppergear.CopperGearMod;
import dev.coppergear.Weathering;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;

public class CopperGearClient implements ClientModInitializer {
    private static CopperChestBlockEntity dummy;

    @Override
    public void onInitializeClient() {
        ResourceLocation stage = new ResourceLocation(CopperGearMod.ID, "stage");
        CopperArmorRenderer armor = new CopperArmorRenderer();
        for (Item item : CopperGearMod.OXIDIZING_ITEMS) {
            ItemProperties.register(item, stage, (stack, level, entity, seed) -> Weathering.stage(stack));
            if (item instanceof ArmorItem) ArmorRenderer.register(armor, item);
        }

        EntityModelLayerRegistry.registerModelLayer(CopperGolemModel.LAYER, CopperGolemModel::createBodyLayer);
        EntityRendererRegistry.register(CopperGearMod.COPPER_GOLEM, CopperGolemRenderer::new);

        BlockEntityRenderers.register(CopperGearMod.COPPER_CHEST_BE, CopperChestRenderer::new);

        Item chestItem = BuiltinRegistriesHelper.chestItem();
        BuiltinItemRendererRegistry.INSTANCE.register(chestItem, (stack, mode, pose, buffers, light, overlay) -> {
            if (dummy == null) dummy = new CopperChestBlockEntity(BlockPos.ZERO, CopperGearMod.COPPER_CHEST.defaultBlockState());
            Minecraft.getInstance().getBlockEntityRenderDispatcher().renderItem(dummy, pose, buffers, light, overlay);
        });
    }

    private static final class BuiltinRegistriesHelper {
        static Item chestItem() {
            return BuiltInRegistries.ITEM.get(new ResourceLocation(CopperGearMod.ID, "copper_chest"));
        }
    }
}
