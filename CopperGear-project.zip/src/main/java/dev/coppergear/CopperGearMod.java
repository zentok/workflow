package dev.coppergear;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.ArrayList;
import java.util.List;

public class CopperGearMod implements ModInitializer {
    public static final String ID = "coppergear";

    public static Block COPPER_CHEST;
    public static BlockEntityType<CopperChestBlockEntity> COPPER_CHEST_BE;
    public static final List<Item> ITEMS = new ArrayList<>();
    public static final List<Item> OXIDIZING_ITEMS = new ArrayList<>();

    private static Item item(String name, Item item, boolean oxidizing) {
        Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(ID, name), item);
        ITEMS.add(item);
        if (oxidizing) OXIDIZING_ITEMS.add(item);
        return item;
    }

    @Override
    public void onInitialize() {
        item("copper_helmet", new CopperArmorItem(ArmorItem.Type.HELMET), true);
        item("copper_chestplate", new CopperArmorItem(ArmorItem.Type.CHESTPLATE), true);
        item("copper_leggings", new CopperArmorItem(ArmorItem.Type.LEGGINGS), true);
        item("copper_boots", new CopperArmorItem(ArmorItem.Type.BOOTS), true);
        item("copper_sword", new CopperTools.Sword(), true);
        item("copper_pickaxe", new CopperTools.Pickaxe(), true);
        item("copper_axe", new CopperTools.Axe(), true);
        item("copper_shovel", new CopperTools.Shovel(), true);
        item("copper_hoe", new CopperTools.Hoe(), true);

        COPPER_CHEST = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(ID, "copper_chest"),
                new CopperChestBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE)
                        .strength(2.5F).sound(SoundType.COPPER)));
        COPPER_CHEST_BE = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, new ResourceLocation(ID, "copper_chest"),
                FabricBlockEntityTypeBuilder.create(CopperChestBlockEntity::new, COPPER_CHEST).build());
        item("copper_chest", new BlockItem(COPPER_CHEST, new Item.Properties()), false);

        CreativeModeTab tab = FabricItemGroup.builder()
                .title(Component.translatable("itemGroup.coppergear"))
                .icon(() -> new ItemStack(OXIDIZING_ITEMS.get(1)))
                .displayItems((params, out) -> ITEMS.forEach(out::accept))
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, new ResourceLocation(ID, "main"), tab);

        // Sneak + right-click the chest with any axe: scrape one oxidation stage.
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            ItemStack held = player.getItemInHand(hand);
            if (hand != InteractionHand.MAIN_HAND || !player.isShiftKeyDown() || !(held.getItem() instanceof AxeItem)) {
                return InteractionResult.PASS;
            }
            if (level.getBlockEntity(hit.getBlockPos()) instanceof CopperChestBlockEntity chest && chest.getStage() > 0) {
                if (!level.isClientSide) {
                    chest.scrape();
                    held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                    level.playSound(null, hit.getBlockPos(), SoundEvents.AXE_SCRAPE, SoundSource.BLOCKS, 1.0F, 1.0F);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
            return InteractionResult.PASS;
        });
    }
}
