package dev.coppergear;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.ArrayList;
import java.util.List;

public class CopperGearMod implements ModInitializer {
    public static final String ID = "coppergear";

    public static Block COPPER_CHEST;
    public static BlockEntityType<CopperChestBlockEntity> COPPER_CHEST_BE;
    public static EntityType<CopperGolem> COPPER_GOLEM;
    public static final List<Item> ITEMS = new ArrayList<>();
    public static final List<Item> OXIDIZING_ITEMS = new ArrayList<>();

    private static Item item(String name, Item item, boolean oxidizing) {
        Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(ID, name), item);
        ITEMS.add(item);
        if (oxidizing) OXIDIZING_ITEMS.add(item);
        return item;
    }

    @Override
    public void onInitialize() {
        item("copper_helmet", new CopperArmorItem(ArmorItem.Type.HELMET), true);
        item("copper_chestplate", new CopperArmorItem(ArmorItem.Type.CHESTPLATE), true);
        item("copper_leggings", new CopperArmorItem(ArmorItem.Type.LEGGINGS), true);
        item("copper_boots", new CopperArmorItem(ArmorItem.Type.BOOTS), true);
        item("copper_sword", new CopperTools.Sword(), true);
        item("copper_pickaxe", new CopperTools.Pickaxe(), true);
        item("copper_axe", new CopperTools.Axe(), true);
        item("copper_shovel", new CopperTools.Shovel(), true);
        item("copper_hoe", new CopperTools.Hoe(), true);

        COPPER_CHEST = Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(ID, "copper_chest"),
                new CopperChestBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE)
                        .strength(2.5F).sound(SoundType.COPPER)));
        COPPER_CHEST_BE = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, new ResourceLocation(ID, "copper_chest"),
                FabricBlockEntityTypeBuilder.create(CopperChestBlockEntity::new, COPPER_CHEST).build());
        item("copper_chest", new BlockItem(COPPER_CHEST, new Item.Properties()), false);

        COPPER_GOLEM = Registry.register(BuiltInRegistries.ENTITY_TYPE, new ResourceLocation(ID, "copper_golem"),
                EntityType.Builder.of(CopperGolem::new, MobCategory.MISC).sized(0.6F, 1.1F).clientTrackingRange(8).build("copper_golem"));
        FabricDefaultAttributeRegistry.register(COPPER_GOLEM, CopperGolem.createAttributes());
        item("copper_golem_spawn_egg", new SpawnEggItem(COPPER_GOLEM, 0xC4673F, 0x4FB39A, new Item.Properties()), false);

        // Build a golem: right-click the top of a copper block with a lightning rod.
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            ItemStack held = player.getItemInHand(hand);
            if (hand != InteractionHand.MAIN_HAND || !held.is(Items.LIGHTNING_ROD) || hit.getDirection() != Direction.UP) {
                return InteractionResult.PASS;
            }
            var block = level.getBlockState(hit.getBlockPos()).getBlock();
            int stage = block == Blocks.COPPER_BLOCK ? 0 : block == Blocks.EXPOSED_COPPER ? 1
                    : block == Blocks.WEATHERED_COPPER ? 2 : block == Blocks.OXIDIZED_COPPER ? 3 : -1;
            if (stage < 0) return InteractionResult.PASS;
            if (!level.isClientSide) {
                var pos = hit.getBlockPos();
                level.removeBlock(pos, false);
                CopperGolem golem = COPPER_GOLEM.create(level);
                if (golem != null) {
                    golem.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, player.getYRot() + 180.0F, 0.0F);
                    golem.setPersistenceRequired();
                    golem.setStageNow(stage);
                    level.addFreshEntity(golem);
                }
                if (!player.getAbilities().instabuild) held.shrink(1);
                level.playSound(null, pos, SoundEvents.COPPER_PLACE, SoundSource.BLOCKS, 1.0F, 0.8F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        });

        CreativeModeTab tab = FabricItemGroup.builder()
                .title(Component.translatable("itemGroup.coppergear"))
                .icon(() -> new ItemStack(OXIDIZING_ITEMS.get(1)))
                .displayItems((params, out) -> ITEMS.forEach(out::accept))
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, new ResourceLocation(ID, "main"), tab);

        // /coppergear stage <0-3>: set oxidation of all copper items in your inventory and the chest you look at.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("coppergear")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("stage")
                                .then(Commands.argument("stage", IntegerArgumentType.integer(0, 3))
                                        .executes(c -> setStage(c.getSource(), IntegerArgumentType.getInteger(c, "stage")))))));

        // Sneak + right-click the chest with any axe: scrape one oxidation stage.
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            ItemStack held = player.getItemInHand(hand);
            if (hand != InteractionHand.MAIN_HAND || !player.isShiftKeyDown() || !(held.getItem() instanceof AxeItem)) {
                return InteractionResult.PASS;
            }
            if (level.getBlockEntity(hit.getBlockPos()) instanceof CopperChestBlockEntity chest && chest.getStage() > 0) {
                if (!level.isClientSide) {
                    chest.scrape();
                    held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                    level.playSound(null, hit.getBlockPos(), SoundEvents.AXE_SCRAPE, SoundSource.BLOCKS, 1.0F, 1.0F);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
            return InteractionResult.PASS;
        });
    }

    private static int setStage(CommandSourceStack src, int stage) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = src.getPlayerOrException();
        int count = 0;
        List<ItemStack> all = new ArrayList<>();
        all.addAll(player.getInventory().items);
        all.addAll(player.getInventory().armor);
        all.addAll(player.getInventory().offhand);
        for (ItemStack s : all) {
            if (!s.isEmpty() && OXIDIZING_ITEMS.contains(s.getItem())) {
                Weathering.setStage(s, stage);
                count++;
            }
        }
        int chests = 0;
        HitResult hit = player.pick(8.0, 0.0F, false);
        if (hit instanceof BlockHitResult bhr && player.level().getBlockEntity(bhr.getBlockPos()) instanceof CopperChestBlockEntity chest) {
            chest.setStage(stage);
            chests = 1;
        }
        int golems = 0;
        for (CopperGolem g : player.level().getEntitiesOfClass(CopperGolem.class, player.getBoundingBox().inflate(8.0))) {
            g.setStageNow(stage);
            golems++;
        }
        count += golems;
        player.inventoryMenu.broadcastChanges();
        final int items = count, ch = chests;
        src.sendSuccess(() -> Component.literal("Copper Gear: stage " + stage + " -> items: " + items + ", chest: " + ch), false);
        return items + ch;
    }
}
