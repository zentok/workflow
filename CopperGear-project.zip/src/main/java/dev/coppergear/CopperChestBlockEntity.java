package dev.coppergear;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A 27-slot chest that oxidizes. The more oxidized it is, the slower the lid
 * moves and the louder it creaks.
 */
public class CopperChestBlockEntity extends ChestBlockEntity {
    private int age;
    private int lastStage;
    private float open, oldOpen;
    private boolean wantOpen;

    public CopperChestBlockEntity(BlockPos pos, BlockState state) {
        super(CopperGearMod.COPPER_CHEST_BE, pos, state);
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.coppergear.copper_chest");
    }

    public int getStage() {
        return Math.min(Weathering.MAX_STAGE, age / Weathering.STAGE_TICKS);
    }

    public void scrape() {
        int st = getStage();
        if (st == 0) return;
        age = (st - 1) * Weathering.STAGE_TICKS;
        lastStage = getStage();
        syncToClients();
    }

    private void syncToClients() {
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    /** Lid speed per tick: vanilla is 0.1. */
    private float lidStep() {
        return switch (getStage()) { case 0 -> 0.10F; case 1 -> 0.065F; case 2 -> 0.04F; default -> 0.022F; };
    }

    @Override
    public boolean triggerEvent(int id, int type) {
        if (id == 1) {
            boolean now = type > 0;
            if (level != null && level.isClientSide && now != wantOpen) creak(now);
            wantOpen = now;
            return true;
        }
        return super.triggerEvent(id, type);
    }

    private void creak(boolean opening) {
        int st = getStage();
        if (st == 0 || level == null) return;
        float volume = 0.25F + 0.2F * st;
        float pitch = (opening ? 0.55F : 0.7F) - 0.05F * st + level.random.nextFloat() * 0.1F;
        level.playLocalSound(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5,
                SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, volume, pitch, false);
    }

    @Override
    public float getOpenNess(float partialTicks) {
        return Mth.lerp(partialTicks, oldOpen, open);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, CopperChestBlockEntity be) {
        if (level.isClientSide) {
            be.oldOpen = be.open;
            float step = be.lidStep();
            be.open = be.wantOpen ? Math.min(1.0F, be.open + step) : Math.max(0.0F, be.open - step);
        } else {
            be.age++;
            int st = be.getStage();
            if (st != be.lastStage) {
                be.lastStage = st;
                be.syncToClients();
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt(Weathering.KEY, age);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        age = tag.getInt(Weathering.KEY);
        lastStage = getStage();
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
