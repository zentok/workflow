package dev.coppergear;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/**
 * Takes a stack from a copper chest and carries it to a nearby chest/barrel that already holds
 * the same item (so the copper chest works as an "input box").
 */
public class CopperGolemCarryGoal extends Goal {
    private static final int RADIUS = 8;
    private static final int MAX_STACK = 16;

    private final CopperGolem golem;
    private BlockPos source, target;
    private int sourceSlot;
    private boolean carrying;
    private int timeout;

    public CopperGolemCarryGoal(CopperGolem golem) {
        this.golem = golem;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (golem.getTarget() != null || golem.getStage() >= Weathering.MAX_STAGE || golem.jobCooldown > 0) return false;
        ItemStack held = golem.getMainHandItem();
        if (!held.isEmpty()) {
            BlockPos t = findTargetFor(held);
            if (t == null) {                       // nowhere to put it: drop it
                golem.spawnAtLocation(held.copy());
                golem.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
                golem.jobCooldown = 100;
                return false;
            }
            source = null; target = t; carrying = true;
            return true;
        }
        if (findJob()) { carrying = false; return true; }
        golem.jobCooldown = 100 + 40 * golem.getStage();
        return false;
    }

    @Override
    public boolean canContinueToUse() {
        return timeout > 0 && golem.getTarget() == null && golem.getStage() < Weathering.MAX_STAGE;
    }

    @Override
    public void start() { timeout = 600; }

    @Override
    public void stop() {
        golem.getNavigation().stop();
        golem.jobCooldown = 40 + 30 * golem.getStage();
        source = null; target = null;
    }

    @Override
    public void tick() {
        timeout--;
        Level level = golem.level();
        if (!carrying) {
            if (source == null) { timeout = 0; return; }
            goNear(source);
            if (near(source)) {
                BlockEntity be = level.getBlockEntity(source);
                if (be instanceof CopperChestBlockEntity chest && sourceSlot < chest.getContainerSize()
                        && !chest.getItem(sourceSlot).isEmpty()) {
                    ItemStack taken = chest.removeItem(sourceSlot, MAX_STACK);
                    golem.setItemSlot(EquipmentSlot.MAINHAND, taken);
                    golem.playSound(SoundEvents.ITEM_PICKUP, 0.5F, 1.0F);
                    BlockPos t = findTargetFor(taken);
                    if (t == null) { timeout = 0; return; }   // next canUse() drops/handles it
                    target = t;
                    carrying = true;
                    timeout = 600;
                } else {
                    timeout = 0;
                }
            }
        } else {
            if (target == null) { timeout = 0; return; }
            goNear(target);
            if (near(target)) {
                Container c = targetContainer(level, target);
                ItemStack held = golem.getMainHandItem();
                if (c != null && !held.isEmpty()) {
                    ItemStack rest = HopperBlockEntity.addItem(null, c, held.copy(), null);
                    golem.setItemSlot(EquipmentSlot.MAINHAND, rest);
                    golem.playSound(SoundEvents.ITEM_PICKUP, 0.5F, 0.8F);
                }
                timeout = 0;
            }
        }
    }

    private void goNear(BlockPos p) {
        if (golem.tickCount % 10 == 0 || golem.getNavigation().isDone()) {
            golem.getNavigation().moveTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, 1.0);
        }
    }

    private boolean near(BlockPos p) {
        return golem.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5) < 6.0;
    }

    private boolean findJob() {
        Level level = golem.level();
        BlockPos c = golem.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-RADIUS, -3, -RADIUS), c.offset(RADIUS, 3, RADIUS))) {
            BlockState st = level.getBlockState(p);
            if (!st.hasBlockEntity()) continue;
            if (!(level.getBlockEntity(p) instanceof CopperChestBlockEntity chest)) continue;
            for (int i = 0; i < chest.getContainerSize(); i++) {
                ItemStack s = chest.getItem(i);
                if (s.isEmpty()) continue;
                BlockPos t = findTargetFor(s);
                if (t != null) {
                    source = p.immutable();
                    sourceSlot = i;
                    target = null;
                    return true;
                }
            }
        }
        return false;
    }

    /** A chest/barrel nearby that already holds this item and has room for it. */
    private BlockPos findTargetFor(ItemStack stack) {
        Level level = golem.level();
        BlockPos c = golem.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-RADIUS, -3, -RADIUS), c.offset(RADIUS, 3, RADIUS))) {
            Container cont = targetContainer(level, p);
            if (cont != null && contains(cont, stack) && hasRoom(cont, stack)) return p.immutable();
        }
        return null;
    }

    private static Container targetContainer(Level level, BlockPos p) {
        BlockState st = level.getBlockState(p);
        if (st.getBlock() instanceof CopperChestBlock) return null;
        if (st.getBlock() instanceof ChestBlock || st.getBlock() instanceof BarrelBlock) {
            return HopperBlockEntity.getContainerAt(level, p);
        }
        return null;
    }

    private static boolean contains(Container c, ItemStack s) {
        for (int i = 0; i < c.getContainerSize(); i++) {
            if (ItemStack.isSameItem(c.getItem(i), s)) return true;
        }
        return false;
    }

    private static boolean hasRoom(Container c, ItemStack s) {
        for (int i = 0; i < c.getContainerSize(); i++) {
            ItemStack in = c.getItem(i);
            if (in.isEmpty()) return true;
            if (ItemStack.isSameItemSameTags(in, s) && in.getCount() < Math.min(c.getMaxStackSize(), in.getMaxStackSize())) return true;
        }
        return false;
    }
}
