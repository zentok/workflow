package dev.coppergear;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;

/**
 * Copper golem: carries items from copper chests into chests/barrels that already hold the same item,
 * and defends the area (with a chance of an electric shock). Oxidizes like all copper; at the last
 * stage it freezes into a statue until scraped with an axe.
 */
public class CopperGolem extends PathfinderMob {
    private static final EntityDataAccessor<Integer> DATA_STAGE =
            SynchedEntityData.defineId(CopperGolem.class, EntityDataSerializers.INT);
    private static final double[] SPEED = {0.28, 0.24, 0.18, 0.0};

    private int age;
    public int jobCooldown = 60;

    public CopperGolem(EntityType<? extends CopperGolem> type, Level level) {
        super(type, level);
        this.setDropChance(EquipmentSlot.MAINHAND, 1.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 5.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.3);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.addGoal(2, new CopperGolemCarryGoal(this));
        goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.6));
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Mob.class, 5, false, false, e -> e instanceof Enemy));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_STAGE, 0);
    }

    public int getStage() { return entityData.get(DATA_STAGE); }

    /** Set oxidation directly (spawn from a copper block, command, scraping). */
    public void setStageNow(int stage) {
        stage = Math.max(0, Math.min(Weathering.MAX_STAGE, stage));
        age = stage * Weathering.STAGE_TICKS;
        applyStage(stage);
    }

    private void applyStage(int stage) {
        entityData.set(DATA_STAGE, stage);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(SPEED[stage]);
        if (stage >= Weathering.MAX_STAGE) {
            getNavigation().stop();
            setTarget(null);
        }
    }

    /** A fully oxidized golem is a statue. */
    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || getStage() >= Weathering.MAX_STAGE;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide) {
            if (jobCooldown > 0) jobCooldown--;
            if (age < Weathering.MAX_STAGE * Weathering.STAGE_TICKS) age++;
            int st = Math.min(Weathering.MAX_STAGE, age / Weathering.STAGE_TICKS);
            if (st != getStage()) applyStage(st);
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity victim && level() instanceof ServerLevel sl) {
            float chance = level().isThundering() ? 1.0F : 0.3F;
            if (random.nextFloat() < chance) {
                victim.hurt(damageSources().lightningBolt(), 4.0F);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, victim.getX(), victim.getY() + victim.getBbHeight() * 0.5, victim.getZ(),
                        14, 0.3, 0.5, 0.3, 0.15);
                playSound(SoundEvents.LIGHTNING_BOLT_IMPACT, 0.4F, 1.6F);
            }
        }
        return hit;
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof AxeItem) {
            int st = getStage();
            if (st > 0) {
                if (!level().isClientSide) {
                    setStageNow(st - 1);
                    held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                    playSound(SoundEvents.AXE_SCRAPE, 1.0F, 1.0F);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }
        if (held.is(Items.COPPER_INGOT) && getHealth() < getMaxHealth()) {
            if (!level().isClientSide) {
                heal(5.0F);
                if (!player.getAbilities().instabuild) held.shrink(1);
                playSound(SoundEvents.COPPER_PLACE, 1.0F, 1.2F);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override public boolean removeWhenFarAway(double distance) { return false; }

    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.COPPER_HIT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.COPPER_BREAK; }
    @Override protected void playStepSound(BlockPos pos, BlockState state) { playSound(SoundEvents.COPPER_STEP, 0.2F, 1.0F); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(Weathering.KEY, age);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        age = tag.getInt(Weathering.KEY);
        applyStage(Math.min(Weathering.MAX_STAGE, age / Weathering.STAGE_TICKS));
    }
}
