package dev.coppergear;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Better than stone, worse than iron. Mines like stone (iron ore yes, diamonds no). */
public enum CopperTier implements Tier {
    INSTANCE;

    @Override public int getUses() { return 180; }
    @Override public float getSpeed() { return 5.0F; }
    @Override public float getAttackDamageBonus() { return 1.5F; }
    @Override public int getLevel() { return 1; }
    @Override public int getEnchantmentValue() { return 10; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.COPPER_INGOT); }
}
