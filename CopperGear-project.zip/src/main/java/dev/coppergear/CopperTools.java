package dev.coppergear;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.SlotAccess;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Copper tools. Each one oxidizes while held in the main hand. */
public final class CopperTools {
    private CopperTools() {}

    private static void age(ItemStack stack, Level level, Entity entity) {
        if (entity instanceof LivingEntity le && le.getMainHandItem() == stack) Weathering.tick(stack, level, entity);
    }

    public static class Sword extends SwordItem {
        public Sword() { super(CopperTier.INSTANCE, 3, -2.4F, new Item.Properties()); }
        @Override public void inventoryTick(ItemStack s, Level l, Entity e, int slot, boolean sel) { age(s, l, e); }
        @Override public boolean overrideOtherStackedOnMe(ItemStack s, ItemStack o, Slot sl, ClickAction a, Player p, SlotAccess acc) { return Weathering.scrape(s, o, sl, a, p); }
        @Override public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) { Weathering.tooltip(s, t); }
    }

    public static class Pickaxe extends PickaxeItem {
        public Pickaxe() { super(CopperTier.INSTANCE, 1, -2.8F, new Item.Properties()); }
        @Override public void inventoryTick(ItemStack s, Level l, Entity e, int slot, boolean sel) { age(s, l, e); }
        @Override public boolean overrideOtherStackedOnMe(ItemStack s, ItemStack o, Slot sl, ClickAction a, Player p, SlotAccess acc) { return Weathering.scrape(s, o, sl, a, p); }
        @Override public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) { Weathering.tooltip(s, t); }
    }

    public static class Axe extends AxeItem {
        public Axe() { super(CopperTier.INSTANCE, 7.0F, -3.2F, new Item.Properties()); }
        @Override public void inventoryTick(ItemStack s, Level l, Entity e, int slot, boolean sel) { age(s, l, e); }
        @Override public boolean overrideOtherStackedOnMe(ItemStack s, ItemStack o, Slot sl, ClickAction a, Player p, SlotAccess acc) { return Weathering.scrape(s, o, sl, a, p); }
        @Override public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) { Weathering.tooltip(s, t); }
    }

    public static class Shovel extends ShovelItem {
        public Shovel() { super(CopperTier.INSTANCE, 1.5F, -3.0F, new Item.Properties()); }
        @Override public void inventoryTick(ItemStack s, Level l, Entity e, int slot, boolean sel) { age(s, l, e); }
        @Override public boolean overrideOtherStackedOnMe(ItemStack s, ItemStack o, Slot sl, ClickAction a, Player p, SlotAccess acc) { return Weathering.scrape(s, o, sl, a, p); }
        @Override public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) { Weathering.tooltip(s, t); }
    }

    public static class Hoe extends HoeItem {
        public Hoe() { super(CopperTier.INSTANCE, -1, -1.5F, new Item.Properties()); }
        @Override public void inventoryTick(ItemStack s, Level l, Entity e, int slot, boolean sel) { age(s, l, e); }
        @Override public boolean overrideOtherStackedOnMe(ItemStack s, ItemStack o, Slot sl, ClickAction a, Player p, SlotAccess acc) { return Weathering.scrape(s, o, sl, a, p); }
        @Override public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) { Weathering.tooltip(s, t); }
    }
}
