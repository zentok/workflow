package dev.coppergear;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

/** Between leather (7 points) and iron (15 points). */
public enum CopperArmorMaterial implements ArmorMaterial {
    INSTANCE;

    @Override public int getDurabilityForType(ArmorItem.Type type) {
        int base = switch (type) { case BOOTS -> 11; case LEGGINGS -> 15; case CHESTPLATE -> 16; case HELMET -> 11; };
        return base * 10;
    }
    @Override public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) { case BOOTS -> 1; case LEGGINGS -> 4; case CHESTPLATE -> 4; case HELMET -> 2; };
    }
    @Override public int getEnchantmentValue() { return 12; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_CHAIN; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.COPPER_INGOT); }
    @Override public String getName() { return "coppergear:copper"; }
    @Override public float getToughness() { return 0.0F; }
    @Override public float getKnockbackResistance() { return 0.0F; }
}
