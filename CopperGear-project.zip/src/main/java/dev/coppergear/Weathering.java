package dev.coppergear;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.ChatFormatting;

import java.util.List;

/** Shared oxidation logic for copper items. Age is stored in the stack NBT. */
public final class Weathering {
    public static final String KEY = "CopperAge";
    public static final int STAGE_TICKS = 24000;   // 20 minutes per stage
    public static final int MAX_STAGE = 3;
    public static final int INTERVAL = 1200;       // age is written once a minute

    private Weathering() {}

    public static int getAge(ItemStack s) {
        CompoundTag t = s.getTag();
        return t == null ? 0 : t.getInt(KEY);
    }

    public static int stage(ItemStack s) {
        return Math.min(MAX_STAGE, getAge(s) / STAGE_TICKS);
    }

    /** Server-side aging, called from inventoryTick. */
    public static void tick(ItemStack s, Level level, Entity holder) {
        if (level.isClientSide || holder.tickCount % INTERVAL != 0) return;
        int age = getAge(s);
        if (age >= MAX_STAGE * STAGE_TICKS) return;
        s.getOrCreateTag().putInt(KEY, age + INTERVAL);
    }

    /** Right-click on the item in an inventory slot with an axe on the cursor. */
    public static boolean scrape(ItemStack stack, ItemStack other, Slot slot, ClickAction action, Player player) {
        if (action != ClickAction.SECONDARY || !(other.getItem() instanceof AxeItem)) return false;
        if (!slot.allowModification(player)) return false;
        int st = stage(stack);
        if (st == 0) return false;
        stack.getOrCreateTag().putInt(KEY, (st - 1) * STAGE_TICKS);
        other.hurtAndBreak(1, player, p -> {});
        player.playSound(SoundEvents.AXE_SCRAPE, 1.0F, 1.0F);
        return true;
    }

    public static void tooltip(ItemStack s, List<Component> tip) {
        int st = stage(s);
        ChatFormatting color = switch (st) {
            case 0 -> ChatFormatting.GOLD;
            case 1 -> ChatFormatting.YELLOW;
            case 2 -> ChatFormatting.DARK_AQUA;
            default -> ChatFormatting.AQUA;
        };
        tip.add(Component.translatable("tooltip.coppergear.stage." + st).withStyle(color));
        if (st > 0) tip.add(Component.translatable("tooltip.coppergear.scrape").withStyle(ChatFormatting.DARK_GRAY));
    }
}
